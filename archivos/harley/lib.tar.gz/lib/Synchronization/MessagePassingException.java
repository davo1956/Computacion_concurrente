package Synchronization;

public final class MessagePassingException extends RuntimeException {
   public MessagePassingException() {super();}
}
