package Synchronization;

public interface Condition {

   public abstract boolean checkCondition(Object m);
}
