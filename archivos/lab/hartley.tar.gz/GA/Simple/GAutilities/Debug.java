package GAutilities;

public class Debug {public static boolean flag = false;}
