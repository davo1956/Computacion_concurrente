package GAutilities;

public class Defaults {
   public static String logFileName = null;
   public static boolean autoFlush = true;
}
