package unam.ciencias.computoconcurrente;

public class AppTest {

    void main() {
    }
}
