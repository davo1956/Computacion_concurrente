package unam.ciencias.computoconcurrente;

public class App {

    public static void main(String[] a) throws InterruptedException {
        
    }
}
